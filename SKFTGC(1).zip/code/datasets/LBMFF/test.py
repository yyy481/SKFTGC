import pandas as pd
import numpy as np
import os

# ======== 配置您的文件路径 ========
# 修改为您的实际文件路径
base_path = r"C:\Users\wanhuasan\Desktop\PANU\CSA_UNet\code\datasets\LBMFF"

# 定义文件路径
drug_path = os.path.join(base_path, "drug.csv")
disease_path = os.path.join(base_path, "disease.csv")
association_path = os.path.join(base_path, "drug_disease.csv")
output_path = os.path.join(base_path, "drug_disease_association_matrix.csv")

# ======== 1. 验证文件存在 ========
for path in [drug_path, disease_path, association_path]:
    if not os.path.exists(path):
        raise FileNotFoundError(f"文件不存在: {path}")

print("所有必要文件都存在，开始处理...")

# ======== 2. 读取数据 ========
try:
    # 读取药物列表
    drugs_df = pd.read_csv(drug_path, usecols=['drug_id'])
    print(f"读取药物列表成功，共 {len(drugs_df)} 条记录")
    
    # 读取疾病列表
    diseases_df = pd.read_csv(disease_path, usecols=['disease_id'])
    print(f"读取疾病列表成功，共 {len(diseases_df)} 条记录")
    
    # 读取药物-疾病关联（智能处理列名）
    association_df = pd.read_csv(association_path)
    
    # 智能识别列名
    drug_col = [col for col in association_df.columns if 'drug' in col.lower()][0]
    disease_col = [col for col in association_df.columns if 'disease' in col.lower()][0]
    
    # 重命名列以确保一致性
    association_df = association_df.rename(columns={
        drug_col: 'drug_id',
        disease_col: 'disease_id'
    })[['drug_id', 'disease_id']]
    
    print(f"读取关联数据成功，共 {len(association_df)} 条关联")
    
except Exception as e:
    print(f"读取文件时出错: {str(e)}")
    raise

# ======== 3. 预处理数据 ========
# 获取唯一的药物ID和疾病ID
all_drug_ids = sorted(drugs_df['drug_id'].astype(str).unique())
all_disease_ids = sorted(diseases_df['disease_id'].astype(str).unique())

print(f"唯一药物数量: {len(all_drug_ids)}")
print(f"唯一疾病数量: {len(all_disease_ids)}")

# 确保关联数据中的ID格式一致
association_df['drug_id'] = association_df['drug_id'].astype(str)
association_df['disease_id'] = association_df['disease_id'].astype(str)

# ======== 4. 构建矩阵 ========
# 更高效的方法：使用pivot_table
matrix = association_df.assign(value=1).pivot_table(
    index='drug_id',
    columns='disease_id',
    values='value',
    aggfunc='max',
    fill_value=0
)

# 确保包含所有药物和疾病
matrix = matrix.reindex(
    index=all_drug_ids, 
    columns=all_disease_ids, 
    fill_value=0
)

print("矩阵构建完成，尺寸:", matrix.shape)

# ======== 5. 保存结果 ========
matrix.to_csv(output_path, index=True, index_label='drug_id')
print(f"矩阵已保存至: {output_path}")

# ======== 6. 分析统计 ========
# 转换为int8节省内存
matrix_int = matrix.astype(np.int8)

total_cells = matrix_int.size
positive_cells = matrix_int.sum().sum()
sparsity = (1 - positive_cells / total_cells) * 100

print("\n=== 统计信息 ===")
print(f"矩阵总单元格数: {total_cells}")
print(f"已知关联数量 (1的个数): {positive_cells}")
print(f"矩阵稀疏度: {sparsity:.2f}%")
print(f"预览前3x3子矩阵:\n{matrix_int.iloc[:3, :3]}")