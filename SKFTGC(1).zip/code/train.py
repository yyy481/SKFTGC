from matplotlib import pyplot as plt
import numpy as np
from torch import nn, optim
import torch
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_curve, average_precision_score
from operator import itemgetter
class Get_loss(nn.Module):
    def __init__(self): # lambda_reg
        super(Get_loss, self).__init__()
        # self.lambda_reg = lambda_reg  # 正则化参数

    def forward(self, one_index, zero_index, target, input, dd, mm, opt): 
        """
        计算新的损失：包括预测误差和正则化项
        :param one_index: 真实连接的节点对
        :param zero_index: 非连接的节点对
        :param target: 真实标签（评分）
        :param input: 模型预测值
        :param dd, mm: 额外的输入数据（可选）
        :param opt: 配置项
        :return: 计算的损失值
        """
        # 计算MSE损失
        mse_loss = nn.MSELoss(reduction='none')
        loss_matrix = mse_loss(input, target)

        # 计算预测误差
        loss = (1 - opt.positive_weight) * loss_matrix[one_index].sum() + opt.positive_weight * loss_matrix[zero_index].sum()

        # 计算正则化项 (L2范数正则化)
        # regularization_loss = self.lambda_reg * (torch.norm(dd, 'fro')**2 + torch.norm(mm, 'fro')**2) / 2

        # 总损失
        total_loss = loss #+ regularization_loss
        return total_loss
    
def train_epoch(model, train_data, optimizer, regression_crit, one_index, zero_index, opt, epoch_losses):  
    """
    训练一个epoch
    """
    model.zero_grad()  # 清零梯度
    score = model(train_data)
    loss = regression_crit(one_index, zero_index, train_data[4].cuda(), score, train_data[0], train_data[1],opt)

    # 记录损失
    epoch_losses.append(loss.item())
    loss.backward()  # 反向传播
    optimizer.step()  # 更新参数
    return loss


def train_model(model, train_data, optimizer, opt):  
    """
    训练整个模型
    """
    model.train()
    regression_crit = Get_loss()
    one_index = train_data[2]['one'].cuda().t().tolist()  # 有联系的节点
    zero_index = train_data[2]['zero'].cuda().t().tolist()
    
    epoch_losses = []  # 存储每个epoch的损失
    for epoch in range(1, opt.epoch + 1):
        loss = train_epoch(model, train_data, optimizer, regression_crit, one_index, zero_index, opt, epoch_losses)
      

from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, roc_curve, precision_recall_curve
from operator import itemgetter
import numpy as np

def find_best_threshold(y_true, y_pred_prob):
    """
    找到最佳阈值（根据 Youden’s Index 和 F1-score）
    """
    fpr, tpr, thresholds_roc = roc_curve(y_true, y_pred_prob)
    youden_index = tpr - fpr
    best_threshold_roc = thresholds_roc[np.argmax(youden_index)]

    precisions, recalls, thresholds_pr = precision_recall_curve(y_true, y_pred_prob)
    f1_scores = 2 * (precisions * recalls) / (precisions + recalls + 1e-9)
    best_threshold_f1 = thresholds_pr[np.argmax(f1_scores)]

    return best_threshold_roc, best_threshold_f1, fpr, tpr

def evaluate_model(y_true, y_pred_prob, threshold):
    """
    根据给定阈值评估模型性能
    """
    y_pred = (np.array(y_pred_prob) >= threshold).astype(int)
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, zero_division=0)
    recall = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    auc_value = roc_auc_score(y_true, y_pred_prob)
    aupr_value = average_precision_score(y_true, y_pred_prob)

    return accuracy, precision, recall, f1, auc_value,aupr_value

def test_model(model, train_data, X_best, Y_best, best_roc_auc,best_acc_f1,best_pre_f1,best_rec_f1,best_aupr_f1,fold_index=None):
    """
    测试模型、计算ROC AUC，并返回各种评估指标与最优阈值
    """
    model.eval()
    score = model(train_data).tolist()
    test_index = train_data[2]['test']
    zero_index = train_data[2]['zero']
    score = model(train_data).cpu().detach().numpy()  # 获取预测分数矩阵并转换为 NumPy 数组

    # # 保存预测分数矩阵到文件
    # np.savetxt('AGCNMC.txt', score, fmt='%10.5f', delimiter=',')
    # print(f"预测分数矩阵已保存到 {'AGCNMC.txt'}")
    y_true = []
    y_pred_prob = []

    for i in range(test_index.size(0)):
        u, v = test_index[i][0], test_index[i][1]
        y_pred_prob.append(score[u][v])
        y_true.append(1)
    for i in range(zero_index.size(0)):
        u, v = zero_index[i][0], zero_index[i][1]
        y_pred_prob.append(score[u][v])
        y_true.append(0)

    # 阈值选择
    best_threshold_roc, best_threshold_f1, fpr, tpr = find_best_threshold(y_true, y_pred_prob)

    # 更新全局最优 ROC 曲线
    roc_auc = roc_auc_score(y_true, y_pred_prob)
    if roc_auc > best_roc_auc:
        best_roc_auc = roc_auc
        X_best = list(fpr)
        Y_best = list(tpr)
        # 保存当前最优预测矩阵
        if fold_index is not None:
            filename = f"AGCNMC_fold{fold_index}.txt"
            np.savetxt(filename, score, fmt='%10.5f', delimiter=',')
            print(f"当前最优分数已保存：{filename}")
    # 评估：使用两个不同的阈值
    acc_roc, pre_roc, rec_roc, f1_roc, auc_roc,aupr_roc = evaluate_model(y_true, y_pred_prob, best_threshold_roc)
    acc_f1, pre_f1, rec_f1, f1_f1, auc_f1,aupr_f1 = evaluate_model(y_true, y_pred_prob, best_threshold_f1)
    if acc_f1 > best_acc_f1:
        best_acc_f1 = acc_f1
    if pre_f1 > best_pre_f1:
        best_pre_f1 = pre_f1
    if rec_f1 > best_rec_f1:
        best_rec_f1 = rec_f1
    if aupr_f1 > best_aupr_f1:
        best_aupr_f1 = aupr_f1
    print(f"最佳阈值 (Youden’s Index): {best_threshold_roc:.4f}")
    print(f"最佳阈值 (F1-score 最大): {best_threshold_f1:.4f}")
    print(f"[ROC] AUC: {auc_roc:.4f} | Acc: {acc_roc:.4f} | Prec: {pre_roc:.4f} | Recall: {rec_roc:.4f} | F1: {f1_roc:.4f}| AUPR: {aupr_roc:.4f}")
    print(f"[F1 ] AUC: {auc_f1:.4f} | Acc: {acc_f1:.4f} | Prec: {pre_f1:.4f} | Recall: {rec_f1:.4f} | F1: {f1_f1:.4f}| AUPR: {aupr_f1:.4f}")
    print(f"acc 最大): {best_acc_f1:.4f}")
    print(f"pre 最大): {best_pre_f1:.4f}")
    print(f"rec 最大): {best_rec_f1:.4f}")
    print(f"aupr 最大): {best_aupr_f1:.4f}")

    return roc_auc, X_best, Y_best, best_roc_auc, acc_f1, pre_f1, rec_f1, f1_f1,aupr_f1,best_threshold_f1,best_acc_f1,best_pre_f1,best_rec_f1,best_aupr_f1
def adjust_learning_rate(optimizer, roc_auc, previous_roc_auc, patience, patience_counter,no_improvement_count,best_roc_auc):
    """
    根据ROC AUC值调整学习率，引入耐心机制
    - patience_counter: 记录已经连续多少轮ROC AUC没有提升
    - previous_roc_auc: 记录上一次的ROC AUC值
    - patience: 当ROC AUC没有提升多少轮时，才减少学习率
    """
    if  roc_auc >= best_roc_auc :    
        patience_counter = 0.0  # 重置耐心计数器
    # if roc_auc >= previous_roc_auc and roc_auc < best_roc_auc :  # 如果AUC提升
    #     patience_counter += 0.5 # 
    else:  # 如果AUC没有提升
        patience_counter += 1.0  # 增加耐心计数器
    print('1',patience_counter)
    print('2',best_roc_auc)   
    print('3',previous_roc_auc)
    print('4',roc_auc)
    # 当耐心计数器达到设定的阈值时，减小学习率
    if patience_counter > patience:
        # 学习率调整策略：逐步减小学习率
        if optimizer.param_groups[0]['lr'] > 0.00001:
            new_lr = optimizer.param_groups[0]['lr'] * 0.7  # 降低学习率
            optimizer.param_groups[0]['lr'] = new_lr
            print(f"Learning rate reduced to {new_lr:.6f}")
        patience_counter = 0  # 重置耐心计数器


    return  patience_counter ,no_improvement_count

