from matplotlib import pyplot as plt
from torch import optim
from prepareData import prepare_data,load_mat
from model import Model
from trainData import Dataset
from train import train_model, test_model, adjust_learning_rate
import torch

class Get_Config(object):
    def __init__(self):
        self.data_path = 'datasets\LBMFF'  # 数据集路径
        self.max_iterations = 50  # 循环次数
        self.test = 50  # 测试次数
        self.save_path = 'datasets\data'
        self.epoch = 1500
        self.positive_weight = 0.3 # 越接近1则越不敢预测，越接近0则越敢预测
        self.beta1 = 1
        self.beta2 = 1        
        self.K = 2  # 预处理参数
        self.namda = 0.4  # 预处理参数

class Date_Sizes(object):
    def __init__(self, dataset):
        self.m = dataset['mm']['data'].size(0)  
        self.d = dataset['dd']['data'].size(0)  

def main():
    opt = Get_Config()
    # 用来存储每轮的最高ROC AUC
    highest_roc_auc_per_iteration = []# 记录每轮的最高AUC
    highest_acc_f1_per_iteration = []  
    highest_pre_f1_per_iteration = []
    highest_rec_f1_per_iteration = []
    highest_aupr_f1_per_iteration = []
    #绘制准确率变化折线图；每轮最高准确率
    #highest_acc_per_iteration=[]
    best_roc_auc = 0.0  # 全局最佳AUC
    best_acc_f1=0.0
    best_pre_f1=0.0
    best_rec_f1=0.0
    best_aupr_f1=0.0
    acc_f1=0.0# 当前
    pre_f1=0.0
    rec_f1=0.0
    aupr_f1=0.0
    roc_auc = 0.0   
    patience = 7.0 # 容忍轮数
    X_best, Y_best = None, None  # 初始化X_best和Y_best
    previous_roc_auc = -float('inf')  # 初始化上一次的ROC AUC为负无穷大
    previous_acc_f1 = -float('inf')
    previous_pre_f1 = -float('inf')
    previous_rec_f1 = -float('inf')
    previous_aupr_f1 = -float('inf')
    filepath=r'C:\Users\clucies\Desktop\Comparative-experiment\CSA_UNet\code\Cdataset.mat' 
    for j in range(opt.max_iterations):
        dataset = prepare_data(opt)
        #dataset=load_mat(filepath)
        train_data = Dataset(opt, dataset)
        sizes = Date_Sizes(dataset)
        model = Model(sizes)
        model.cuda()
        optimizer = optim.Adam(model.parameters(), lr=0.001, betas=(0.9, 0.999), weight_decay=1e-5)
        # optimizer = optim.Adam(model.parameters(), lr=0.001, betas=(0.9, 0.999), weight_decay=1e-5)  # 恒定学习率
        highest_roc_auc_this_iteration = 0.0  # 用来存储当前轮次的最高ROC AUC
        highest_acc_f1_this_iteration = 0.0
        highest_pre_f1_this_iteration = 0.0
        highest_rec_f1_this_iteration = 0.0
        highest_aupr_f1_this_iteration = 0.0

        #highest_acc_this_iteration = 0.0  # 记录当前轮次的最高准确率

        no_improvement_count = 0.0  # 记录未提升次数
        patience_counter = 0.0 # 下降次数
        for i in range(opt.test):
            train_model(model, train_data[i], optimizer, opt)
            roc_auc, X_best, Y_best, best_roc_auc,acc_f1, pre_f1, rec_f1, f1_f1,aupr_f1,best_threshold_f1,best_acc_f1,best_pre_f1,best_rec_f1,best_aupr_f1= test_model(model, train_data[0], X_best, Y_best, best_roc_auc,best_acc_f1,best_pre_f1,best_rec_f1,best_aupr_f1)
            

            if roc_auc >= highest_roc_auc_this_iteration:
                highest_roc_auc_this_iteration = roc_auc 
                no_improvement_count = 0.0  # 重置未提升计数
            if roc_auc < highest_roc_auc_this_iteration: 
                if roc_auc>previous_roc_auc:
                    no_improvement_count += 0.5
                else:
                    no_improvement_count += 1.0     
            else:
                no_improvement_count += 1.0  # 未提升计数加1
            # 更新当前轮次的最高ROC AUC

            if acc_f1 >= highest_acc_f1_this_iteration:
                highest_acc_f1_this_iteration = acc_f1 
            if pre_f1 >= highest_pre_f1_this_iteration:
                highest_pre_f1_this_iteration = pre_f1 
            if rec_f1 >= highest_rec_f1_this_iteration:
                highest_rec_f1_this_iteration = rec_f1 
            if aupr_f1 >= highest_aupr_f1_this_iteration:
                highest_aupr_f1_this_iteration = aupr_f1 
            print('0',no_improvement_count)           # 调整学习率    
            patience_counter ,no_improvement_count= adjust_learning_rate(optimizer, roc_auc, previous_roc_auc, 2, patience_counter, no_improvement_count,highest_roc_auc_this_iteration)
            previous_roc_auc = roc_auc
            previous_acc_f1 = acc_f1
            previous_pre_f1 = pre_f1
            previous_rec_f1 = rec_f1
            previous_aupr_f1 = aupr_f1

            print(f"Test {i+1} in iteration {j+1} - ROC AUC: {roc_auc}")
            # 检查是否需要早停
            if no_improvement_count > patience:
                print(f"Early stopping at test {i+1} in iteration {j+1}. Best ROC AUC in this iteration: {highest_roc_auc_this_iteration}")
                break

        # 保存当前轮次的最高ROC AUC到列表
        highest_roc_auc_per_iteration.append(highest_roc_auc_this_iteration)
        highest_acc_f1_per_iteration.append(highest_acc_f1_this_iteration)
        highest_pre_f1_per_iteration.append(highest_pre_f1_this_iteration)
        highest_rec_f1_per_iteration.append(highest_rec_f1_this_iteration)
        highest_aupr_f1_per_iteration.append(highest_aupr_f1_this_iteration)

        # 打印当前轮次的最高ROC AUC
        print(f"Highest ROC AUC in iteration {j+1}: {highest_roc_auc_this_iteration}")
        print(f"Best ROC AUC after all iterations: {best_roc_auc}")
        
        print(f"Highest acc f1 in iteration {j+1}: {highest_acc_f1_this_iteration}")
        print(f"Best acc f1 after all iterations: {best_acc_f1}")

        print(f"Highest pre f1 in iteration {j+1}: {highest_pre_f1_this_iteration}")
        print(f"Best pre f1 after all iterations: {best_pre_f1}")

        print(f"Highest rec f1 in iteration {j+1}: {highest_rec_f1_this_iteration}")
        print(f"Best rec f1 after all iterations: {best_rec_f1}")

        print(f"Highest aupr f1 in iteration {j+1}: {highest_aupr_f1_this_iteration}")
        print(f"Best aupr f1 after all iterations: {best_aupr_f1}")

        print(f"Best f1-score after all iterations: {best_threshold_f1}")

    # 输出每轮训练后的最高AUC
    print("Highest ROC AUC per iteration:")
    for i, auc in enumerate(highest_roc_auc_per_iteration, 1):
        print(f"Iteration {i}: {auc}")
    # 输出全局最佳AUC
    print(f"Global Best ROC AUC after all iterations: {best_roc_auc}")
    print(f"Global Best acc after all iterations: {best_acc_f1}")
    print(f"Global Best pre after all iterations: {best_pre_f1}")
    print(f"Global Best rec after all iterations: {best_rec_f1}")
    print(f"Global Best f1 after all iterations: {best_threshold_f1}")
    print(f"Global Best aupr after all iterations: {best_aupr_f1}")

    # 最终绘制全局最佳ROC曲线
    if X_best is not None and Y_best is not None:  
        plt.plot(X_best, Y_best, 'k--', label=f'Best ROC (area = {best_roc_auc:.4f})', lw=2)
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('Best ROC Curve')
        plt.legend(loc="lower right")
        plt.show()
        plt.savefig('highest_aupr_per_iteration.png', dpi=500, bbox_inches='tight')
    #绘制折线图准确率
    if len(highest_acc_f1_per_iteration) > 0:  # 确保有数据才绘图
        iterations = list(range(1, opt.max_iterations + 1))  # x轴：迭代次数（1,2,...,max_iterations）
        plt.figure(figsize=(10, 6))  # 设置图大小
        plt.plot(iterations, highest_acc_f1_per_iteration, 'b-o', label='Highest Accuracy per Iteration', lw=2, markersize=6)
        plt.xlabel('Iteration Number', fontsize=12)
        plt.ylabel('Highest Accuracy', fontsize=12)
        plt.title('Highest Accuracy Change with Iterations', fontsize=14, fontweight='bold')
        plt.legend(fontsize=10)
        plt.grid(True, alpha=0.3)  # 显示网格（增强可读性）
        plt.xticks(iterations)  # x轴刻度与迭代次数对应
        plt.show()
        plt.savefig('highest_accuracy_per_iteration.png', dpi=500, bbox_inches='tight')
        
if __name__ == "__main__":
    main()
